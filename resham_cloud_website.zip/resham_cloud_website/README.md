# Resham Cloud Website

Responsive service website built with HTML, CSS, and Python Flask.

## Run
1. Install Python 3.9+.
2. In this folder run:
   `python -m venv .venv`
3. Activate it (`.venv\\Scripts\\activate` on Windows or `source .venv/bin/activate` on macOS/Linux).
4. Install: `pip install -r requirements.txt`
5. Start: `python app.py`
6. Visit `http://127.0.0.1:5000`.

## Admin
- Login URL: `/admin/login`
- Default username: `admin`
- Default password: `admin`
- Change the default password immediately after first login. New passwords require at least 8 characters.
- 3 failed login attempts trigger a 15-minute IP-based lockout.
- Admin can add, edit, view and delete named URLs in a table.
- Admin-managed URLs are not shown on the public homepage.

## Production security
Set a strong random `SECRET_KEY`, enable HTTPS, and use a production WSGI server. The simple IP rate limiter is in-memory and resets on restart; use a persistent rate limiter and database for a public production deployment. Do not run Flask debug mode in production.
