from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from pathlib import Path
import json, os, time

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "replace-this-secret-key-before-deployment")
BASE = Path(__file__).resolve().parent
AUTH, LINKS = BASE/"admin_auth.json", BASE/"links.json"
attempts = {}
LIMIT, LOCK_SECONDS = 3, 900

def load(path, default):
    try: return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except (OSError, json.JSONDecodeError): return default

def save(path, data): path.write_text(json.dumps(data, indent=2), encoding="utf-8")
def auth_data():
    data = load(AUTH, None)
    if data is None:
        data = {"username":"admin", "password_hash":generate_password_hash("admin")}
        save(AUTH, data)
    return data
def links(): return load(LINKS, [])
def save_links(data): save(LINKS, data)
def admin_only(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get("admin"): return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapped

@app.get("/")
def home(): return render_template("index.html")

@app.route("/admin/login", methods=["GET","POST"])
def login():
    ip = request.remote_addr or "unknown"
    rec = attempts.get(ip, {"count":0,"until":0})
    locked = time.time() < rec["until"]
    if session.get("admin"): return redirect(url_for("dashboard"))
    if request.method == "POST":
        if locked:
            flash("Too many failed attempts. Try again in 15 minutes.", "error")
        else:
            a = auth_data()
            if request.form.get("username","").strip() == a["username"] and check_password_hash(a["password_hash"], request.form.get("password","")):
                attempts.pop(ip, None); session.clear(); session["admin"] = True
                return redirect(url_for("dashboard"))
            rec["count"] += 1
            if rec["count"] >= LIMIT: rec = {"count":0,"until":time.time()+LOCK_SECONDS}
            attempts[ip] = rec
            flash("Invalid login. " + ("Login locked for 15 minutes." if rec["until"] else f"{LIMIT-rec['count']} attempt(s) remaining."), "error")
            locked = time.time() < rec["until"]
    return render_template("login.html", locked=locked)

@app.get("/admin/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.get("/admin")
@admin_only
def dashboard(): return render_template("admin.html", links=links())

@app.route("/admin/add", methods=["GET","POST"])
@admin_only
def add():
    if request.method == "POST":
        name, url = request.form.get("name","").strip(), request.form.get("url","").strip()
        if not name or not url or not url.startswith(("https://","http://")): flash("Enter a name and a valid http:// or https:// URL.", "error")
        else:
            data=links(); data.append({"id":max([x.get("id",0) for x in data],default=0)+1,"name":name,"url":url}); save_links(data)
            flash("Link added.", "success"); return redirect(url_for("dashboard"))
    return render_template("link_form.html", title="Add link", item=None)

@app.route("/admin/edit/<int:item_id>", methods=["GET","POST"])
@admin_only
def edit(item_id):
    data=links(); item=next((x for x in data if x.get("id")==item_id),None)
    if item is None: abort(404)
    if request.method=="POST":
        name,url=request.form.get("name","").strip(),request.form.get("url","").strip()
        if not name or not url or not url.startswith(("https://","http://")): flash("Enter a name and a valid URL.", "error")
        else:
            item.update(name=name,url=url); save_links(data); flash("Link updated.", "success"); return redirect(url_for("dashboard"))
    return render_template("link_form.html", title="Edit link", item=item)

@app.post("/admin/delete/<int:item_id>")
@admin_only
def delete(item_id):
    data=links(); updated=[x for x in data if x.get("id")!=item_id]
    if len(data)==len(updated): abort(404)
    save_links(updated); flash("Link deleted.", "success"); return redirect(url_for("dashboard"))

@app.get("/admin/view/<int:item_id>")
@admin_only
def view(item_id):
    item=next((x for x in links() if x.get("id")==item_id),None)
    if item is None: abort(404)
    return render_template("view.html", item=item)

@app.route("/admin/change-password", methods=["GET","POST"])
@admin_only
def change_password():
    if request.method=="POST":
        data=auth_data(); old=request.form.get("current",""); new=request.form.get("new",""); confirm=request.form.get("confirm","")
        if not check_password_hash(data["password_hash"],old): flash("Current password is incorrect.","error")
        elif len(new)<8: flash("New password must be at least 8 characters.","error")
        elif new!=confirm: flash("New passwords do not match.","error")
        else:
            data["password_hash"]=generate_password_hash(new); save(AUTH,data); flash("Password changed.","success"); return redirect(url_for("dashboard"))
    return render_template("password.html")

if __name__=="__main__": app.run(host="127.0.0.1",port=5000,debug=True)
